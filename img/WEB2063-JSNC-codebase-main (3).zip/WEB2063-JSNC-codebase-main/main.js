function renderProductRow(product) {
  return `
          <tr>
      <th scope="row">${product.id}</th>
      <td>${product.title}</td>
      <td>${product.image}</td>
      <td>${product.price}</td>
      <td>${product.brand}</td>
      <td>${product.isHot}</td>
      <td><a href="/edit.html?id=${product.id}" ><button class="btn btn-primary ">Edit</button></a>
      <button class="btn btn-danger" onClick=deleteProduct('${product.id}') ">Delete</button></td>

    </tr>
    `;
}

async function showProductList() {
  const res = await axios.get("http://localhost:3000/products");
  const products = res.data;
  document.getElementById("list").innerHTML = `
    <table class="table">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Title</th>
          <th scope="col">Image</th>
          <th scope="col">Price</th>
          <th scope="col">Bran</th>
          <th scope="col">Is Hot</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        ${products.map(renderProductRow).join("")}
      </tbody>
    </table>
    `;
}
showProductList();

async function deleteProduct(id) {
  try {
    if (confirm("Ban chac chan muon xoa chu??")) {
      await axios.delete(`http://localhost:3000/products/${id}`);
    }
  } catch (error) {
    alert("error");
  }
}
