async function handleSubmit(event) {
  event.preventDefault();
  console.log("handSubmit");

  const productTitle = document.getElementById("title").value;
  const productImage = document.getElementById("image").value;
  const productPrice = document.getElementById("price").value;
  const productBran = document.getElementById("bran").value;
  const productIsHot = document.getElementById("isHot").value;

  const data = {
    title: productTitle,
    image: productImage,
    price: Number(productPrice),
    brand: productBran,
    isHot: productIsHot,
  };

  try {
    await axios.post("http://localhost:3000/products/", data);

    location.href = "/";
    alert("Them san pham thanh cong");
  } catch (error) {
    alert("khong thanh cong");
  }
}
