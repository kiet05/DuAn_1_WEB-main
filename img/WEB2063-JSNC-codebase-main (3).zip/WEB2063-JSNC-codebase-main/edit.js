const productId = location.search.split("=")[1];

async function getProductDetail() {
  const res = await axios.get(`http://localhost:3000/products/${productId}`);
  console.log(res.data);

  document.getElementById("title").value = res.data.title;
  document.getElementById("image").value = res.data.image;
  document.getElementById("price").value = res.data.price;
  document.getElementById("bran").value = res.data.bran;
  document.getElementById("isHot").value = res.data.isHot;
}
getProductDetail();

async function handleSubmit(event) {
  event.preventDefault();

  const productTitle = document.getElementById("title").value;
  const productImage = document.getElementById("image").value;
  const productPrice = document.getElementById("price").value;
  const productBran = document.getElementById("bran").value;
  const productIsHot = document.getElementById("isHot").value;

  const data = {
    title: productTitle,
    image: productImage,
    price: Number(productPrice),
    brand: productBran,
    isHot: productIsHot,
  };

  try {
    if (productId) {
      await axios.put(`http://localhost:3000/products/${productId}`, data);
    } else {
      await axios.post("http://localhost:3000/products/", data);
    }

    location.href = "/";
    alert("Sua san pham thanh cong");
  } catch (error) {
    alert("khong thanh cong");
  }
}
